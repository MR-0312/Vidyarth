import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Headers from './components/Header';
import Footers from './components/Footer';
import Home from './pages/Home';
import BookList from './pages/BookList';
import BookDetails from './pages/BookDetails';
import Login from './pages/Login';
import Register from './pages/Register';
import Profile from './pages/Profile';
import { AuthProvider } from './contexts/AuthContext';
import { Flex, Layout } from 'antd';
import './App.css';
const {Content} = Layout;


function App() {
  return (
    <AuthProvider>
      <Router>
        <Flex gap="middle" wrap>
        <Layout className='layoutStyle'>
        {/* <div className="app"> */}
          <Headers />
          {/* <Content>           */}
            <main>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/books" element={<BookList />} />
              <Route path="/books/:id" element={<BookDetails />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/profile" element={<Profile />} />
            </Routes>
          </main>
          {/* </Content> */}
          <Footers />
        {/* </div> */}
        </Layout>
        </Flex>
      </Router>
    </AuthProvider>
  );
}

export default App;

