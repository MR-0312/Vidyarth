import React from 'react';
import { Footer } from 'antd/es/layout/layout';
function Footers() {
  return (
    <Footer>
    <footer className="bg-gray-200 p-4 mt-8">
      <div className="container mx-auto text-center">
        <p>&copy; 2024 Vidyarth eBook Platform. All rights reserved.</p>
      </div>
    </footer> 
    </Footer>
  );
}

export default Footers;

