import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Header } from 'antd/es/layout/layout';
import { Flex } from 'antd';

function Headers() {
  const { user, logout } = useAuth();

  return (
    <Header>
      <Flex >

    <header className="bg-blue-600 text-white p-4">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold">Vidyarth eBook Library</Link>
        {/* <nav>
          <ul className="flex space-x-4">
            <li><Link to="/" className="hover:text-blue-200">Home</Link></li>
            <li><Link to="/books" className="hover:text-blue-200">Books</Link></li>
            {user ? (
              <>
                <li><Link to="/profile" className="hover:text-blue-200">Profile</Link></li>
                <li><button onClick={logout} className="hover:text-blue-200">Logout</button></li>
              </>
            ) : (
              <>
                <li><Link to="/login" className="hover:text-blue-200">Login</Link></li>
                <li><Link to="/register" className="hover:text-blue-200">Register</Link></li>
              </>
            )}
          </ul>
        </nav> */}
      </div>
    </header>
            </Flex>
    </Header>
  );
}

export default Headers;

